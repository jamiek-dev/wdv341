<?php 
define('SERVERNAME', '127.0.0.1');
define('USERNAME', 'root');
define('PASSWORD', ''); 
define('DATABASE', 'wdv341');
?>