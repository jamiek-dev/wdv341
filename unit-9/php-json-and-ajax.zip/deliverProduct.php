<?php
/**
 * Simple, quick way to create a baseic class object
 */
$productObj = new stdClass();
$productObj->productName = "Product 1";
//$productObj->productPrice = "$1.99";
// $returnObj = $productObj;
// $returnObj = json_encode($productObj); // Create the JSON object
// echo $returnObj; // Send results back to calling program
?>